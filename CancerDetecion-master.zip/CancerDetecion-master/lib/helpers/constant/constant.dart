import 'package:hexcolor/hexcolor.dart';

HexColor iconColor  = HexColor("545FDD") ;

HexColor buttonColor  = HexColor("394EFF") ;

HexColor textColor = HexColor('1F245B');